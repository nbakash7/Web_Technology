document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('.registration-form form');
    const validationMessage = document.getElementById('validationMessage');
    
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        clearErrorHighlights();

        const isNameValid = validateName();
        const isEmailValid = validateEmail();
        const isPasswordValid = validatePassword();
        const isLocationValid = validateLocation();
        const isPostalCodeValid = validatePostalCode();
        const isCourseValid = validateCourse();
        const isTermsValid = validateTerms();
        
        if (isNameValid && isEmailValid && isPasswordValid && 
            isLocationValid && isPostalCodeValid && isCourseValid && isTermsValid) {
            showSuccessMessage();
        }
    });

    function showMessage(message, isError = true) {
        validationMessage.textContent = message;
        validationMessage.style.backgroundColor = isError ? '#ff4444' : '#4CAF50';
        validationMessage.classList.add('show');
        
        setTimeout(() => {
            validationMessage.classList.remove('show');
        }, 5000);
    }

    function showSuccessMessage() {
        showMessage('Registration successful! Thank you for signing up.', false);
    }

    function highlightError(element) {
        element.classList.add('error-field');
        element.focus();
    }

    function clearErrorHighlights() {
        document.querySelectorAll('.error-field').forEach(el => {
            el.classList.remove('error-field');
        });
    }

    function validateName() {
        const nameInput = document.getElementById('name');
        const nameValue = nameInput.value.trim();
        
        if (nameValue === '') {
            showMessage('Please enter your full name');
            highlightError(nameInput);
            return false;
        }

        if (!/^[a-zA-Z\s]{3,}$/.test(nameValue)) {
            showMessage('Name should contain at least 3 letters and no numbers');
            highlightError(nameInput);
            return false;
        }

        return true;
    }

    function validateEmail() {
        const emailInput = document.getElementById('email');
        const emailValue = emailInput.value.trim();
        const emailRegex = /^[0-9]{2}-[0-9]{5}(-[0-9])?@student\.aiub\.edu$/;

        if (emailValue === '') {
            showMessage('Please enter your email address');
            highlightError(emailInput);
            return false;
        }

        if (!emailRegex.test(emailValue)) {
            showMessage('Please enter a valid AIUB student email (e.g., @student.aiub.edu)');
            highlightError(emailInput);
            return false;
        }

        return true;
    }

    function validatePassword() {
        const passwordInput = document.getElementById('pass');
        const confirmPasswordInput = document.getElementById('cPassword');
        const passwordValue = passwordInput.value.trim();
        const confirmPasswordValue = confirmPasswordInput.value.trim();

        if (passwordValue === '') {
            showMessage('Please enter a password');
            highlightError(passwordInput);
            return false;
        }

        if (passwordValue.length < 8) {
            showMessage('Password must be at least 8 characters long');
            highlightError(passwordInput);
            return false;
        }

        if (confirmPasswordValue === '') {
            showMessage('Please confirm your password');
            highlightError(confirmPasswordInput);
            return false;
        }

        if (passwordValue !== confirmPasswordValue) {
            showMessage('Passwords do not match');
            highlightError(confirmPasswordInput);
            return false;
        }

        return true;
    }

    function validateLocation() {
        const locationInput = document.getElementById('location');
        const locationValue = locationInput.value.trim();

        if (locationValue === '') {
            showMessage('Please enter your location');
            highlightError(locationInput);
            return false;
        }

        return true;
    }

    function validatePostalCode() {
        const postalCodeInput = document.getElementById('pCode');
        const postalCodeValue = postalCodeInput.value.trim();

        if (postalCodeValue === '') {
            showMessage('Please enter your postal code');
            highlightError(postalCodeInput);
            return false;
        }

        if (!/^\d{4}$/.test(postalCodeValue)) {
            showMessage('Postal code must be exactly 4 digits');
            highlightError(postalCodeInput);
            return false;
        }

        return true;
    }

    function validateCourse() {
        const courseSelect = document.getElementById('course');
        const courseValue = courseSelect.value;

        if (courseValue === '') {
            showMessage('Please select your preferred course');
            highlightError(courseSelect);
            return false;
        }

        return true;
    }

    function validateTerms() {
        const termsCheckbox = document.getElementById('terms');

        if (!termsCheckbox.checked) {
            showMessage('You must agree to the terms and conditions');
            highlightError(termsCheckbox);
            return false;
        }

        return true;
    }
});
